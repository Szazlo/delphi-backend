def read_last_n_logs(logfile="events.log", n=5):
    """Reads the last `n` lines from the log file."""
    try:
        with open(logfile, "r") as f:
            lines = f.readlines()
            return lines[-n:] if lines else ["No logs found."]
    except FileNotFoundError:
        return ["Log file not found."]
