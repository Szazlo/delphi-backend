import time
from logger import log_event
from reader import read_last_n_logs


def main():
    print("Starting event logger...\n")

    # Generate and log events automatically
    for _ in range(5):  # Simulate 5 events over time
        log_entry = log_event()
        print(f"Logged: {log_entry}")

    # Read the last 5 log entries
    print("\nRecent Log Entries:")
    logs = read_last_n_logs()
    for log in logs:
        print(log.strip())


if __name__ == "__main__":
    main()
