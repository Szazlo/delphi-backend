
def square_numbers(numbers):
    squared = []
    for num in numbers:
        squared.append(num ** 2)
    return squared

def sum_of_multiples(multiplier, limit):
    """Returns the sum of multiplier*i for i from 1..limit."""
    return sum(multiplier * i for i in range(1, limit + 1))
