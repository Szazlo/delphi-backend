def read_numbers_from_file(filename):
    """Reads numbers from a file and returns them as a list of integers."""
    try:
        with open(filename, "r") as file:
            return [int(line.strip()) for line in file.readlines()]
    except FileNotFoundError:
        print("File not found. Please make sure 'data.txt' exists.")
        return []
    except ValueError:
        print("Invalid data in file. Please ensure it contains only numbers.")
        return []


def read_cases_from_file(filename):
    """Reads lines containing 'multiplier limit' pairs from a file."""
    pairs = []
    try:
        with open(filename, "r") as file:
            for line in file:
                parts = line.strip().split()
                if len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit():
                    pairs.append((int(parts[0]), int(parts[1])))
    except FileNotFoundError:
        print("File not found.")
    return pairs
