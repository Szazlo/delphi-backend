from math_utils import sum_of_multiples


def main():
    t = int(input())

    for _ in range(t):
        multiplier_str, limit_str = input().split()
        multiplier = int(multiplier_str)
        limit_val = int(limit_str)
        total_sum = sum_of_multiples(multiplier, limit_val)
        print(total_sum)


if __name__ == '__main__':
    main()