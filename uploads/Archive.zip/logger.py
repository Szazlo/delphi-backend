import time
import random

EVENTS = ["User logged in", "File uploaded", "Error occurred", "Data processed", "User logged out"]


def log_event(logfile="events.log"):
    """Logs a random event with a timestamp."""
    event = random.choice(EVENTS)
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")

    with open(logfile, "a") as f:
        f.write(f"{timestamp} - {event}\n")

    return f"{timestamp} - {event}"
