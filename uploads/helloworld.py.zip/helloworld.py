def hello():
    printing("Hello, World!")

if __name__ == "__main__":
    hello()
