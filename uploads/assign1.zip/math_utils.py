import time


def square_numbers(numbers):
    squared = []
    for num in numbers:
        squared.append(num ** 2)
    return squared
