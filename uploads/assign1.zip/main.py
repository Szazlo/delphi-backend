import sys
import time
from math_utils import square_numbers
from file_utils import read_numbers_from_file


def read_numbers_from_stdin():
    """Reads numbers from stdin if provided."""
    try:
        return [int(line.strip()) for line in sys.stdin if line.strip().isdigit()]
    except ValueError:
        print("Invalid input. Please provide only numbers.", file=sys.stderr)
        return []


def main():
    # Check if there's input from stdin
    if sys.stdin.isatty():  # No stdin, read from file
        print("No stdin detected. Reading numbers from data.txt...", file=sys.stderr)
        numbers = read_numbers_from_file("data.txt")
    else:  # Read from stdin
        print("Reading numbers from stdin...", file=sys.stderr)
        numbers = read_numbers_from_stdin()

    if not numbers:
        print("No valid numbers found. Exiting.", file=sys.stderr)
        return

    print("Squaring numbers, please wait...", file=sys.stderr)
    squared_numbers = square_numbers(numbers)

    # Output results to stdout
    for num, squared in zip(numbers, squared_numbers):
        print(f"{num} squared is {squared}")


if __name__ == "__main__":
    main()
