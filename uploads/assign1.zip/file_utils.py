def read_numbers_from_file(filename):
    """Reads numbers from a file and returns them as a list of integers."""
    try:
        with open(filename, "r") as file:
            return [int(line.strip()) for line in file.readlines()]
    except FileNotFoundError:
        print("File not found. Please make sure 'data.txt' exists.")
        return []
    except ValueError:
        print("Invalid data in file. Please ensure it contains only numbers.")
        return []
